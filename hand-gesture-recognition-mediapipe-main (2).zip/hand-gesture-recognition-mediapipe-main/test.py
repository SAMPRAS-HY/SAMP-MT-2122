import handsdetec as hd

hd.main()